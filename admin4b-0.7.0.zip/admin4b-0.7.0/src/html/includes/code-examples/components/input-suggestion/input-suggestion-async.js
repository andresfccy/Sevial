$('#my-input').on('suggestion:search', function () {
    // Your magic
    $input.suggestion('refresh');
});
