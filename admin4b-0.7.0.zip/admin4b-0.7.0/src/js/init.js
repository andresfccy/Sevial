$(function () {
  $('input').typing();
  $('.as-input').asInput();
  $('[data-toggle="popover"]').popover();
  $('[data-toggle="tooltip"]').tooltip();
  $('[data-toggle="suggestion"]').suggestion();
});
